// Dipakai index.html untuk mengetahui bahwa fungsi pratinjau berita aktif.
export async function onRequestGet() {
  return new Response(JSON.stringify({ ok: true }), {
    headers: { 'content-type': 'application/json', 'cache-control': 'no-store' }
  });
}
